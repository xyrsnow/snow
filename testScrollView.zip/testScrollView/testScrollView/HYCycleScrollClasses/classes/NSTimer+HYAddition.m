//
//  NSTimer+HYAddition.m
//  testScrollView
//
//  Created by necsthz on 15/7/15.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import "NSTimer+HYAddition.h"

@implementation NSTimer (HYAddition)

- (void)pauseTimer
{
    if (![self isValid]) {
        return;
    }
    [self setFireDate:[NSDate distantFuture]];
}

- (void)resumeTimer
{
    if (![self isValid]) {
        return;
    }
    [self setFireDate:[NSDate date]];
}

- (void)resumeTimerAfterInterval:(NSTimeInterval)interval
{
    if (![self isValid]) {
        return;
    }
    [self setFireDate:[NSDate dateWithTimeIntervalSinceNow:interval]];
}

@end
