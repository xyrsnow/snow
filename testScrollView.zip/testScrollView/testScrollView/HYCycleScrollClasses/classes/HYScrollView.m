//
//  HYScrollView.m
//  testScrollView
//
//  Created by necsthz on 15/7/14.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import "HYScrollView.h"
#import "UIImageView+WebCache.h"

@interface HYScrollView ()<UIGestureRecognizerDelegate>

@property (nonatomic, strong) NSArray *imgUrls;

@end

@implementation HYScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.scrollsToTop = NO;
        self.pagingEnabled = YES;
        self.bounces = NO;
        self.userInteractionEnabled = YES;
        [self setContentOffset:CGPointMake(0, 0)];
        [self setContentOffset:CGPointMake(self.frame.size.width, 0)];
        UITapGestureRecognizer *recognizerGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
        recognizerGesture.numberOfTapsRequired = 1;
        [self addGestureRecognizer:recognizerGesture];
        
        if (!_pageControl) {
            self.pageControl = [[UIPageControl alloc] init];
            self.pageControl.currentPage = 0;
            self.pageControl.userInteractionEnabled = YES;
            [self.pageControl addTarget:self action:@selector(pageTurn:) forControlEvents:UIControlEventTouchUpInside];
            
        
        }
        _isAutoScroll = NO;
    }
    return self;
}

- (void)pageTurn:(UIPageControl *)sender
{
    CGSize viewSize = self.frame.size;
    [self setContentOffset:CGPointMake((sender.currentPage + 1) *viewSize.width, 0) animated:YES];
}

- (void)HYScrollViewDidScroll
{
    CGFloat pageWidth = self.frame.size.width;
    if (self.contentOffset.x < self.bounds.size.width) {
       [self setContentOffset:CGPointMake((self.imgUrls.count + 1)*self.bounds.size.width, 0)];
    }
    if (_isAutoScroll) {
        if (self.contentOffset.x == (self.imgUrls.count + 1)*self.bounds.size.width) {
            [self setContentOffset:CGPointMake(pageWidth, 0)];
        }
    }
    int page = floor((self.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.currentPageIndex = page;
    self.pageControl.currentPage = self.currentPageIndex - 1;
}

- (void)HYScrollViewDidEndDecelerating
{
    if (self.imgUrls.count != 0) {
        if (0 == self.currentPageIndex) {
            [self setContentOffset:CGPointMake((self.imgUrls.count +1)*self.bounds.size.width, 0)];
        }
        if ((self.imgUrls.count + 1) == self.currentPageIndex) {
            [self setContentOffset:CGPointMake(self.bounds.size.width, 0)];
        }
    }
}

- (void)setImageUrls:(NSArray *)urls
{
    if (urls.count != 0) {
        self.imgUrls = urls;
        self.contentSize = CGSizeMake(self.frame.size.width *(urls.count + 2), self.frame.size.height);
        
        UIImageView *beginImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        beginImageView.backgroundColor = [UIColor yellowColor];
        beginImageView.image = urls[urls.count - 1];
        //[beginImageView sd_setImageWithURL:[NSURL URLWithString:urls[urls.count -1]] placeholderImage:nil];
        [self addSubview:beginImageView];
        
        for (int i = 0; i < urls.count; i++){
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((i+1)*self.frame.size.width, 0, self.frame.size.width, self.frame.size.height)];
            [self addSubview:imageView];
            //[imageView sd_setImageWithURL:[NSURL URLWithString:urls[i]] placeholderImage:nil];
            imageView.image = urls[i];
        }
        self.pageControl.numberOfPages = urls.count;
        UIImageView *endImageView = [[UIImageView alloc] initWithFrame:CGRectMake((urls.count+1)*self.frame.size.width, 0, self.frame.size.width, self.frame.size.height)];
        endImageView.backgroundColor = [UIColor redColor];
        endImageView.image = urls[0];
        //[endImageView sd_setImageWithURL:[NSURL URLWithString:urls[0]] placeholderImage:nil];
        [self addSubview:endImageView];
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if (touch.view == _pageControl) {
        return NO;
    }
    return YES;
}

- (void)tap
{
    [self.scrollDelegate tapImageView:self.pageControl.currentPage];
}

@end
