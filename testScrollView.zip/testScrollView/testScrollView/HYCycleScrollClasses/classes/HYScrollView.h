//
//  HYScrollView.h
//  testScrollView
//
//  Created by necsthz on 15/7/14.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HYScrollViewDelegate <NSObject>

@optional
- (void)tapImageView:(NSInteger)index;

@end

@interface HYScrollView : UIScrollView <HYScrollViewDelegate>

@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, assign) NSInteger currentPageIndex;
@property (nonatomic, weak) id <HYScrollViewDelegate> scrollDelegate;
@property (nonatomic, assign) BOOL isAutoScroll;

- (void)HYScrollViewDidScroll;
- (void)HYScrollViewDidEndDecelerating;

- (void)setImageUrls:(NSArray *)urls;

@end
