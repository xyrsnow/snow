//
//  NSTimer+HYAddition.h
//  testScrollView
//
//  Created by necsthz on 15/7/15.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSTimer (HYAddition)

- (void)pauseTimer;
- (void)resumeTimer;
- (void)resumeTimerAfterInterval:(NSTimeInterval)interval;

@end
