//
//  HYCycleScrollView.h
//  testScrollView
//
//  Created by necsthz on 15/7/17.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYCycleScrollView : UIView

- (void)setImgUrls:(NSArray *)urls withAnimationTime:(NSTimeInterval)time;

@end
