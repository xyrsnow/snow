//
//  HYCycleScrollView.m
//  testScrollView
//
//  Created by necsthz on 15/7/17.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import "HYCycleScrollView.h"
#import "HYScrollView.h"
#import "NSTimer+HYAddition.h"

@interface HYCycleScrollView ()<UIScrollViewDelegate,HYScrollViewDelegate>

@property (nonatomic, strong) HYScrollView *scrollView;
@property (nonatomic, strong) NSTimer *animationTimer;
@property (nonatomic, assign) NSTimeInterval animationTime;

@end

@implementation HYCycleScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _scrollView = [[HYScrollView alloc] initWithFrame:self.bounds];
        _scrollView.delegate = self;
        _scrollView.scrollDelegate = self;
        [self addSubview:_scrollView];
        
        _scrollView.pageControl.frame = CGRectMake(0, CGRectGetMaxY(_scrollView.frame) - 20, _scrollView.frame.size.width, 20);
        _scrollView.pageControl.pageIndicatorTintColor = [UIColor whiteColor];
        _scrollView.pageControl.currentPageIndicatorTintColor = [UIColor redColor];
        _scrollView.pageControl.currentPage = 0;
        [self addSubview:_scrollView.pageControl];
    }
    return self;
}

- (void)setImgUrls:(NSArray *)urls withAnimationTime:(NSTimeInterval)time
{
//    _urls = @[@"http://pic1.nipic.com/2008-09-08/200898163242920_2.jpg",
//              @"http://pic26.nipic.com/20121223/9252150_195341264315_2.jpg",
//              @"http://pic1.nipic.com/2008-08-12/200881211331729_2.jpg",
//              @"http://pica.nipic.com/2008-05-07/20085722191339_2.jpg"];
    [_scrollView setImageUrls:urls];
    _animationTime = time;
    
    if (!_animationTimer) {
        _animationTimer = [NSTimer scheduledTimerWithTimeInterval:_animationTime target:self selector:@selector(changeImg:) userInfo:nil repeats:YES];
    }

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_scrollView HYScrollViewDidScroll];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [_scrollView HYScrollViewDidEndDecelerating];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    self.scrollView.isAutoScroll = NO;
    [self.animationTimer pauseTimer];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [self.animationTimer resumeTimerAfterInterval:_animationTime];
    self.scrollView.isAutoScroll = YES;
}

- (void)tapImageView:(NSInteger)index
{
    NSLog(@"点击第%ld张图片", index);
}

- (void)changeImg:(NSTimer *)timer
{
    self.scrollView.isAutoScroll = YES;
    CGSize viewSize = self.scrollView.frame.size;
    int pages = floor(self.scrollView.contentOffset.x/viewSize.width) + 1;
    [self.scrollView setContentOffset:CGPointMake(pages*viewSize.width, 0) animated:YES];
}



@end
