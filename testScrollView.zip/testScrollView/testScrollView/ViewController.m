//
//  ViewController.m
//  testScrollView
//
//  Created by necsthz on 15/7/14.
//  Copyright (c) 2015年 necsthz. All rights reserved.
//

#import "ViewController.h"
#import "HYCycleScrollView.h"

@interface ViewController ()

@property (nonatomic, strong) HYCycleScrollView *scrollView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _scrollView = [[HYCycleScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 150)];
    [self.view addSubview:_scrollView];
    
    NSArray *imageArr = @[[UIImage imageNamed:@"00.jpg"],[UIImage imageNamed:@"01.jpg"],[UIImage imageNamed:@"02.jpg"]];
    [_scrollView setImgUrls:imageArr withAnimationTime:3.0f];
   /* dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *urls = @[@"http://pic1.nipic.com/2008-09-08/200898163242920_2.jpg",
                          @"http://pic26.nipic.com/20121223/9252150_195341264315_2.jpg",
                          @"http://pic1.nipic.com/2008-08-12/200881211331729_2.jpg",
                          @"http://pica.nipic.com/2008-05-07/20085722191339_2.jpg"];
        
        [_scrollView setImgUrls:urls withAnimationTime:3.0f];
    });
    */
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
