//
//  QYViewController.h
//  FocusView
//
//  Created by qingyun on 14-10-24.
//  Copyright (c) 2014年 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QYViewController : UIViewController

@end
