//
//  FocusView.m
//  FocusView
//
//  Created by qingyun on 14-10-24.
//  Copyright (c) 2014年 qingyun. All rights reserved.
//

#import "FocusView.h"

@implementation FocusView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame Images:(NSArray *)images{
    self = [super initWithFrame:frame];
    if (self) {
        //组合图片
        NSMutableArray *mutableArray = [[NSMutableArray alloc] initWithCapacity:images.count +2];
        [mutableArray addObject:images.lastObject];
        [mutableArray addObjectsFromArray:images];
        [mutableArray addObject:images[0]];
        self.images = mutableArray;
    }
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    //初始化内容
    UIScrollView *crollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height)];
    crollView.contentSize = CGSizeMake(self.images.count  * self.frame.size.width, self.frame.size.height);
    self.scrollView = crollView;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    
    for (int i = 0; i < self.images.count; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithImage:self.images[i]];
        imageView.frame = CGRectOffset(self.scrollView.frame, i* self.frame.size.width, 0);
        [self.scrollView addSubview:imageView];
        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapImageviewAction:)];
        [imageView addGestureRecognizer:gesture];
        imageView.userInteractionEnabled = YES;
    }
    [self addSubview:self.scrollView];
    //默认显现第0张图片
    [self.scrollView setContentOffset:CGPointMake(self.frame.size.width, 0)];
    
    _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake((self.bounds.size.width-80)*0.5, CGRectGetMaxY(self.scrollView.frame)-20, 80, 20)];
    self.pageControl.numberOfPages = self.images.count - 2;
    self.pageControl.currentPage = 0;
    self.pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    self.pageControl.currentPageIndicatorTintColor = [UIColor cyanColor];
    [self addSubview:self.pageControl];
    
}

-(void)startTimer{
    //启动一个定时器
    if (!self.timer) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(timerFire:) userInfo:nil repeats:YES];
    }
}

-(void)timerFire:(NSTimer*)timer{
//    设置srlloView偏移
    //判断偏移量，确定何时回归第零张
    /*
    CGPoint point = CGPointZero;
    
    //int page = (int) self.pageControl.currentPage;
    if (self.scrollView.contentOffset.x < (self.images.count - 1) *self.frame.size.width) {
        
        point = CGPointMake(self.frame.size.width+self.scrollView.contentOffset.x, 0);
        [UIView animateWithDuration:.5f animations:^{
            
            [self.scrollView setContentOffset:point animated:NO];
            self.pageControl.currentPage = (self.scrollView.contentOffset.x - self.frame.size.width)/self.frame.size.width;
        }];

           
    }else {
        
        point = CGPointMake(self.frame.size.width, 0);
        [UIView animateWithDuration:.2f animations:^{
            
            [self.scrollView setContentOffset:point animated:NO];
            self.pageControl.currentPage = 0;
            
        }];

    }
     */
    
    
    [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x+self.frame.size.width, 0)];
}

-(void)stopTimer{
    //停止Timer；
    [self.timer invalidate];
    self.timer = nil;
}


-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    //开始拖拽
    [self stopTimer];
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    //停止拖拽
    [self startTimer];
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    /*
    if (self.scrollView.contentOffset.x < 0) {
        
        [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width*(self.images.count -2), 0)];
        self.pageControl.currentPage = 2;
    }
    
    if (self.scrollView.contentOffset.x > (self.images.count -1) *scrollView.frame.size.width) {
        
        [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width, 0)];
        self.pageControl.currentPage = (scrollView.contentOffset.x - scrollView.bounds.size.width)/scrollView.bounds.size.width;
    }
     */
    
    if (scrollView.contentOffset.x/scrollView.bounds.size.width >= (self.images.count - 1)) {
        
        [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width, 0)];
    }
    self.pageControl.currentPage = scrollView.contentOffset.x /self.frame.size.width -1;
    
    if (scrollView.contentOffset.x <= 0) {
        
        [scrollView setContentOffset:CGPointMake(scrollView.frame.size.width *(self.images.count -2), 0)];
    }
}

- (void)tapImageviewAction:(UITapGestureRecognizer *)gesture
{
    [self.delegate tapImageviewToViewController];
}

@end
